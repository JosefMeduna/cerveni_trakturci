
package net.mcreator.modteam.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.item.UseAction;
import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.Food;
import net.minecraft.client.util.ITooltipFlag;

import net.mcreator.modteam.itemgroup.FarmareniItemGroup;
import net.mcreator.modteam.ModTeamModElements;

import java.util.List;

@ModTeamModElements.ModElement.Tag
public class RizekItem extends ModTeamModElements.ModElement {
	@ObjectHolder("mod_team:rizek")
	public static final Item block = null;
	public RizekItem(ModTeamModElements instance) {
		super(instance, 13);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new FoodItemCustom());
	}
	public static class FoodItemCustom extends Item {
		public FoodItemCustom() {
			super(new Item.Properties().group(FarmareniItemGroup.tab).maxStackSize(64).rarity(Rarity.COMMON)
					.food((new Food.Builder()).hunger(4).saturation(2f).build()));
			setRegistryName("rizek");
		}

		@Override
		public UseAction getUseAction(ItemStack itemstack) {
			return UseAction.EAT;
		}

		@Override
		public void addInformation(ItemStack itemstack, World world, List<ITextComponent> list, ITooltipFlag flag) {
			super.addInformation(itemstack, world, list, flag);
			list.add(new StringTextComponent("vysoce v\u00FD\u017Eivn\u00E9 j\u00EDdlo."));
		}
	}
}
